
"use strict";

let call_rec_name = require('./call_rec_name.js');

module.exports = {
  call_rec_name: call_rec_name,
};
