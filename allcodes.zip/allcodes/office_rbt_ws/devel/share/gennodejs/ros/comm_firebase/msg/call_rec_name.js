// Auto-generated. Do not edit!

// (in-package comm_firebase.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class call_rec_name {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.caller = null;
      this.receiver = null;
    }
    else {
      if (initObj.hasOwnProperty('caller')) {
        this.caller = initObj.caller
      }
      else {
        this.caller = '';
      }
      if (initObj.hasOwnProperty('receiver')) {
        this.receiver = initObj.receiver
      }
      else {
        this.receiver = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type call_rec_name
    // Serialize message field [caller]
    bufferOffset = _serializer.string(obj.caller, buffer, bufferOffset);
    // Serialize message field [receiver]
    bufferOffset = _serializer.string(obj.receiver, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type call_rec_name
    let len;
    let data = new call_rec_name(null);
    // Deserialize message field [caller]
    data.caller = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [receiver]
    data.receiver = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.caller.length;
    length += object.receiver.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'comm_firebase/call_rec_name';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8503cd37e46bd1d966fb9f76ec5a7f8f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string caller
    string receiver
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new call_rec_name(null);
    if (msg.caller !== undefined) {
      resolved.caller = msg.caller;
    }
    else {
      resolved.caller = ''
    }

    if (msg.receiver !== undefined) {
      resolved.receiver = msg.receiver;
    }
    else {
      resolved.receiver = ''
    }

    return resolved;
    }
};

module.exports = call_rec_name;
