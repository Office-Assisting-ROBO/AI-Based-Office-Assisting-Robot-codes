
"use strict";

let navigation = require('./navigation.js');
let appMsg = require('./appMsg.js');

module.exports = {
  navigation: navigation,
  appMsg: appMsg,
};
