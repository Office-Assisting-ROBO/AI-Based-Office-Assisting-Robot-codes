// Auto-generated. Do not edit!

// (in-package user_interface.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class appMsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name_pickup = null;
      this.xt = null;
      this.yt = null;
      this.name_deliver = null;
      this.xg = null;
      this.yg = null;
    }
    else {
      if (initObj.hasOwnProperty('name_pickup')) {
        this.name_pickup = initObj.name_pickup
      }
      else {
        this.name_pickup = '';
      }
      if (initObj.hasOwnProperty('xt')) {
        this.xt = initObj.xt
      }
      else {
        this.xt = 0.0;
      }
      if (initObj.hasOwnProperty('yt')) {
        this.yt = initObj.yt
      }
      else {
        this.yt = 0.0;
      }
      if (initObj.hasOwnProperty('name_deliver')) {
        this.name_deliver = initObj.name_deliver
      }
      else {
        this.name_deliver = '';
      }
      if (initObj.hasOwnProperty('xg')) {
        this.xg = initObj.xg
      }
      else {
        this.xg = 0.0;
      }
      if (initObj.hasOwnProperty('yg')) {
        this.yg = initObj.yg
      }
      else {
        this.yg = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type appMsg
    // Serialize message field [name_pickup]
    bufferOffset = _serializer.string(obj.name_pickup, buffer, bufferOffset);
    // Serialize message field [xt]
    bufferOffset = _serializer.float32(obj.xt, buffer, bufferOffset);
    // Serialize message field [yt]
    bufferOffset = _serializer.float32(obj.yt, buffer, bufferOffset);
    // Serialize message field [name_deliver]
    bufferOffset = _serializer.string(obj.name_deliver, buffer, bufferOffset);
    // Serialize message field [xg]
    bufferOffset = _serializer.float32(obj.xg, buffer, bufferOffset);
    // Serialize message field [yg]
    bufferOffset = _serializer.float32(obj.yg, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type appMsg
    let len;
    let data = new appMsg(null);
    // Deserialize message field [name_pickup]
    data.name_pickup = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [xt]
    data.xt = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [yt]
    data.yt = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [name_deliver]
    data.name_deliver = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [xg]
    data.xg = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [yg]
    data.yg = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name_pickup.length;
    length += object.name_deliver.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'user_interface/appMsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fb68487a87a6e6cb477e1dbefb63bc86';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name_pickup
    float32 xt
    float32 yt
    string name_deliver
    float32 xg
    float32 yg
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new appMsg(null);
    if (msg.name_pickup !== undefined) {
      resolved.name_pickup = msg.name_pickup;
    }
    else {
      resolved.name_pickup = ''
    }

    if (msg.xt !== undefined) {
      resolved.xt = msg.xt;
    }
    else {
      resolved.xt = 0.0
    }

    if (msg.yt !== undefined) {
      resolved.yt = msg.yt;
    }
    else {
      resolved.yt = 0.0
    }

    if (msg.name_deliver !== undefined) {
      resolved.name_deliver = msg.name_deliver;
    }
    else {
      resolved.name_deliver = ''
    }

    if (msg.xg !== undefined) {
      resolved.xg = msg.xg;
    }
    else {
      resolved.xg = 0.0
    }

    if (msg.yg !== undefined) {
      resolved.yg = msg.yg;
    }
    else {
      resolved.yg = 0.0
    }

    return resolved;
    }
};

module.exports = appMsg;
