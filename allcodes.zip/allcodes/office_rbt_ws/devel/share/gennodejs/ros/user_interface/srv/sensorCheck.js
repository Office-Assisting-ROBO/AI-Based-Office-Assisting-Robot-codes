// Auto-generated. Do not edit!

// (in-package user_interface.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class sensorCheckRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.check = null;
    }
    else {
      if (initObj.hasOwnProperty('check')) {
        this.check = initObj.check
      }
      else {
        this.check = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sensorCheckRequest
    // Serialize message field [check]
    bufferOffset = _serializer.string(obj.check, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sensorCheckRequest
    let len;
    let data = new sensorCheckRequest(null);
    // Deserialize message field [check]
    data.check = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.check.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'user_interface/sensorCheckRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6cfc6e9c16d121985612b1eef2b26d5a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string check
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sensorCheckRequest(null);
    if (msg.check !== undefined) {
      resolved.check = msg.check;
    }
    else {
      resolved.check = ''
    }

    return resolved;
    }
};

class sensorCheckResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensor_status = null;
    }
    else {
      if (initObj.hasOwnProperty('sensor_status')) {
        this.sensor_status = initObj.sensor_status
      }
      else {
        this.sensor_status = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sensorCheckResponse
    // Serialize message field [sensor_status]
    bufferOffset = _serializer.string(obj.sensor_status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sensorCheckResponse
    let len;
    let data = new sensorCheckResponse(null);
    // Deserialize message field [sensor_status]
    data.sensor_status = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.sensor_status.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'user_interface/sensorCheckResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1ec9d4e1079f25affc79cd926e51b3bd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string sensor_status
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sensorCheckResponse(null);
    if (msg.sensor_status !== undefined) {
      resolved.sensor_status = msg.sensor_status;
    }
    else {
      resolved.sensor_status = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: sensorCheckRequest,
  Response: sensorCheckResponse,
  md5sum() { return 'b8ac7a0bf1d404cb08775e2a88cfb43b'; },
  datatype() { return 'user_interface/sensorCheck'; }
};
