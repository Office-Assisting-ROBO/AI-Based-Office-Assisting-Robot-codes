import tkinter as tk

# if you are still working under a Python 2 version,
# comment out the previous line and uncomment the following line
# import Tkinter as tk

root = tk.Tk()
def message_pass(message):
    w = tk.Label(root, text=message)
    w.pack()
    root.mainloop()

message = "Emergency stop pressed"
message_pass(message)