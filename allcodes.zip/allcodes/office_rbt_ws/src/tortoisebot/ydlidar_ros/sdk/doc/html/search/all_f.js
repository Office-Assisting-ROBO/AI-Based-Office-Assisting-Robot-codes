var searchData=
[
  ['readme',['README',['../md__home_yang_lidar_ws_src_sdk_README.html',1,'']]],
  ['range',['range',['../struct_laser_point.html#a11f1cc1b1b04456edcfd30254aaa5e08',1,'LaserPoint']]],
  ['rate',['rate',['../structsampling__rate.html#a8d860fbedd930d2022fe7bb6cf1f78b6',1,'sampling_rate']]],
  ['read',['read',['../classserial_1_1_serial.html#a01fc2e3d77cb7d70069de87eca1400e9',1,'serial::Serial::read(uint8_t *buffer, size_t size)'],['../classserial_1_1_serial.html#a3ecd4645c76548ba079eab6f2f46adfb',1,'serial::Serial::read(std::vector&lt; uint8_t &gt; &amp;buffer, size_t size=1)'],['../classserial_1_1_serial.html#ad6c6637fdf8edd85c3a6a63d98fc18f7',1,'serial::Serial::read(std::string &amp;buffer, size_t size=1)'],['../classserial_1_1_serial.html#aa52fbf7d23fb761a46e2400829d2b77a',1,'serial::Serial::read(size_t size=1)']]],
  ['read_5ftimeout_5fconstant',['read_timeout_constant',['../structserial_1_1_timeout.html#a099244649dec66b6e0548480edeb2b9f',1,'serial::Timeout']]],
  ['read_5ftimeout_5fmultiplier',['read_timeout_multiplier',['../structserial_1_1_timeout.html#a64412753eb2edf1621716dd9f1a4e71e',1,'serial::Timeout']]],
  ['readdata',['readData',['../classserial_1_1_serial.html#a23af62642b1739cf31fb1c8a272074a1',1,'serial::Serial']]],
  ['readline',['readline',['../classserial_1_1_serial.html#a010b18ec545dfe1a7bb1c95be4bdaa54',1,'serial::Serial::readline(std::string &amp;buffer, size_t size=65536, std::string eol=&quot;\n&quot;)'],['../classserial_1_1_serial.html#a04177f637cc02f92ec0492d377528b2a',1,'serial::Serial::readline(size_t size=65536, std::string eol=&quot;\n&quot;)']]],
  ['readlines',['readlines',['../classserial_1_1_serial.html#a2ff222081c30ee4343498c6cc5c14b10',1,'serial::Serial']]],
  ['reset',['reset',['../classydlidar_1_1_y_dlidar_driver.html#a3dd4086c5685163f7c7487ea0f5af08c',1,'ydlidar::YDlidarDriver']]]
];
