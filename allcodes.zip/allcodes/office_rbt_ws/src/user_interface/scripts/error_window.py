from tkinter import *
from PIL import ImageTk, Image
import rospy
from std_msgs.msg import Bool

# lock = rospy.Publisher('/Lock_open_close', Bool, queue_size=10)
# loc = False
def ConfWindow(message):
    global lock, loc, counter
    # Destroy old frames to start a new UI
    # frame.destroy()
    root = Tk()
    root.attributes('-fullscreen', True)
    initial_frame = LabelFrame(root, text="Confirmation")
    initial_frame.grid(row=0, column=0)
    conf_img = ImageTk.PhotoImage(Image.open("/home/pratik/office_rbt_ws/src/user_interface/scripts/dark-blue-wallpaper-hd-3.jpg"))
    conf_label = Label(initial_frame, image=conf_img)
    conf_label.grid(row=0, column=0)
    conf_frame = LabelFrame(root)#, padx=50, pady=50, background="dark-blue-wallpaper-hd-3.jpg")
    conf_frame.grid(row=0, column=0)
    Label(root, text=message)
    conf_pickup = Button(conf_frame, text="Reset Robot Sensors", width=50, height=10, command=lambda: printfn(root))  # ok is a variable but temporarily considered as a string
    conf_pickup.grid(row=0, column=0, padx=10, pady=10)
    root.mainloop()

def printfn(root):
    #print("ok")
    root.destroy()



